package com.example.coderspocketdict;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class FullDictionary extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_dictionary);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        printFullDict();
    }

    public void printFullDict() {
        ArrayList<String> allWords = CodersPocketDict.getKeys();
        String finalOutput = "";

        for (String s : allWords) {
            finalOutput += String.format("%s | ", s);
        }

        ((TextView) findViewById(R.id.allWords)).setText(finalOutput);
    }

    public void refresh(View v) {
        printFullDict();
    }
}