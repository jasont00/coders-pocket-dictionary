package com.example.coderspocketdict;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    private Button fullDict;
    private Button addWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fullDict = (Button) findViewById(R.id.fullDict);
        addWord = (Button) findViewById(R.id.addWord);

        addWord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { openAddWord(); }

        });
        fullDict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFullDict();
            }

        });
        CodersPocketDict dict = new CodersPocketDict();
        dict.fill();
    }

    public void buttonClicked(View v) {
        EditText wordInput = (EditText) findViewById(R.id.search);
        String word = wordInput.getText().toString();

        String retWord = "";
        String retDef = "";

        if (CodersPocketDict.getDict().containsKey(word.toLowerCase())) {
            retWord = CodersPocketDict.capFirst(CodersPocketDict.definition(word)[0]);
            retDef = CodersPocketDict.definition(word)[1];
        }
        else {
            retDef = "Word is not in the dictionary";
        }

        ((TextView) findViewById(R.id.word)).setText(retWord);
        ((TextView) findViewById(R.id.def)).setText(retDef);
    }

    public void openFullDict() {
        Intent intent = new Intent(this, FullDictionary.class);

        startActivity(intent);
    }

    public void openAddWord() {
        Intent intent = new Intent(this, AddWord.class);

        startActivity(intent);
    }

}