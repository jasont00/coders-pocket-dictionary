package com.example.coderspocketdict;

import java.util.*;

public class CodersPocketDict {

    static TreeMap<String, String> dict = new TreeMap<>();

    public CodersPocketDict(){
        fill();
    } // constructor that fills up the map

    public static String capFirst(String inp) { // method to capitalize the first letter of a string
        return inp.substring(0,1).toUpperCase() + inp.substring(1);
    }

    public static TreeMap<String, String> getDict() {
        return dict;
    }

    public static ArrayList getKeys(){ // gets all the keys in the map (all possible words to search up)

        ArrayList<String> keys = new ArrayList<>();

        for(String i : dict.keySet()){
            keys.add(i);
        }
        return keys;
    }

    public static String[] definition(String input) { // returns definition of word/value of key
        String[] wordAndDef = new String[2];

        wordAndDef[0] = input;
        wordAndDef[1] = dict.get(input);

        return wordAndDef;
    }

    public static void fill() { // all the base words
        dict.put("android", "a mobile operating system developed by google. it is based on a modified version of the linux kernel and other open source software and is designed primarily for touchscreen mobile devices such as smartphones, tablets, watches, tvs");
        dict.put("activity", "a single screen of user interface (ui) that appears in your app");
        dict.put("view", "items that appear onscreen in an activity");
        dict.put("widget", "view object that serves as an interface for interaction with the user");
        dict.put("event", "action that occurs when user interacts with widgets");
        dict.put("action bar", "a menu of common actions at top of app");
        dict.put("notification area", "topmost system menu and icons");
        dict.put("exceptions", "an important instrument in java use to signal abnormal (or exceptional) conditions in the program flow which may prevent it to make a further progress.");
        dict.put("exception", "describes errors caused by your program and external circumstances. these errors can be caught and handled by your program.");
        dict.put("collection", "a group of individual elements, often with some rule applied to them.");
        dict.put("collections", "allow many objects to be collected/stored together and then passed around as a single object (i.e., the array itself can be viewed as an object (without inheritance)).");
        dict.put("lists", "ordered collections of values that allow the client to add and remove elements.");
        dict.put("list", "an abstract data type that implements an ordered collection of values, where the same value may occur more than once.");
        dict.put("sets", "unordered collections of values in which a particular object can appear at most once (no duplication).");
        dict.put("set", "an abstract data type that does not allow duplicate elements to be added");
        dict.put("maps" , "structures that create associations between keys and values. the hashmap and treemap classes are in this category");
        dict.put("map", "a group of key-value object pairs.");
        dict.put("object oriented design", "a method of decomposing software architectures based on the objects that every systems or subsystem manipulates.");
        dict.put("program", "a set of instructions, written in a programming language, to be executed (carried out, performed) to get some task done.");
        dict.put("compiler", "a program that translates a program into a machine language form so that it can be executed on a computer.");
        dict.put("java", "general-purpose language: 'write code once, run anywhere.'");
        dict.put("objects", "basic runtime entities in an object-oriented system. they may represent a person, a place, a bank account, a table of data or any item that your program has to handle.");
        dict.put("object", "conceptually integrated data collection that encapsulates state and behavior.");
        dict.put("classes", "data types based on which objects are created.");
        dict.put("class", "template that defines the common structure for all objects of that class.");
        dict.put("methods", " actions that can be performed by objects become functions of the class.");
        dict.put("constructor", "a specialized method that acts as a factory for making new instances of a particular class.");
        dict.put("abstraction", "a distancing between ideas and details.");
        dict.put("encapsulation", " bundling data and methods that use the data into a single unit");
        dict.put("aliases", "two or more references that refer to the same object are called aliases of each other");
        dict.put("ragged arrays", "when the rows of a two-dimensional array are of different lengths,");
        dict.put("interface", "contains method declarations and may contain constants.");
        dict.put("model view controller", "separates user interface from other parts of the system");
        dict.put("model", "manages the behavior and data of the application domain, responds to requests for information about its state (usually from the view), and responds to instructions to change state (usually from the controller).");
        dict.put("view", "displays the model state and usually has components that allow user to edit change the model state");
        dict.put("controller", "contains the objects that control and handle the user’s interaction with the view and the model.");
        dict.put("pseudocode", "high-level description of an algorithm, less detailed than a program");
        dict.put("variables", "instances of mathematical 'types' orclass type");
        dict.put("literal ", "a programming-language representation of a value.");
        dict.put("immutable", "classes that prohibit clients from changing an object’s state are said to be immutable.");
        dict.put("precondition", "a condition that the client must ensure is true immediately before a method is invoked/called.");
        dict.put("postcondition", "a condition that the method must ensure is true immediately after the method is finished.");
        dict.put("algorithm", "series of actions in a specific order");
        dict.put("break", "a break statement causes control to transfer to the end of the switch statement.");
        dict.put("type cast", "a conversion from one data type to another");
        dict.put("string", "a sequence of characters that is treated as a single value.");
        dict.put("instantiation", "creating an object");
        dict.put("array", "an object that stores many values of the same type.");
        dict.put("element", "a value in an array.");
        dict.put("index", "a 0-based integer to access an element from an array.");
        dict.put("induction", "a mathematical method for proving that a statement is valid for a (possibly infinite) sequence of objects.");
        dict.put("recursion", "defining an operation in terms of itself.");
        dict.put("recursive method ", "a method that calls itself.");
    }



}
