package com.example.coderspocketdict;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class AddWord extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_word);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void addNewWord(View v) {
        EditText wordInput = (EditText) findViewById(R.id.wordInp);
        String word = wordInput.getText().toString().toLowerCase();

        EditText defInput = (EditText) findViewById(R.id.defInp);
        String def = defInput.getText().toString().toLowerCase();

        String msg = ""; // message that is displayed
        if (CodersPocketDict.dict.keySet().size() < 30 + CodersPocketDict.dict.keySet().size()) {
            if (CodersPocketDict.dict.containsKey(word)) { // checks if word already exists in dictionary
                msg = "This term already exists in the dictionary.\nThe definition will be updated if this is a user-inputted word."; // change this to display something
                CodersPocketDict.dict.put(word, def);
            }
            else { // otherwise add word
                msg = "The term was added successfully.";
                CodersPocketDict.dict.put(word, def);
            }
        }

        else {
            msg = "You have reached the limit of words that can be added.";
        }

        ((TextView) findViewById(R.id.msgAdd)).setText(msg);
    }

    public void removeWord(View v) {
        EditText wordInput = (EditText) findViewById(R.id.remInp);
        String word = wordInput.getText().toString().toLowerCase();

        String msg = "";

        if (CodersPocketDict.dict.containsKey(word)) {
            msg = "The term was removed if it was a user-inputted word.";
            CodersPocketDict.dict.remove(word);
        }
        else {
            msg = "The term does not exist in the dictionary.";
        }

        ((TextView) findViewById(R.id.msgAdd)).setText(msg);
    }




}