package com.example.coderspocketdict;

import org.junit.Test;

import static org.junit.Assert.*;

public class PocketDictTest {
    @Test
    public void definitionTest_01(){ // word input is always turned to lowercase
        CodersPocketDict.fill();
        assertEquals("activity", CodersPocketDict.definition("activity")[0]);
        assertEquals("a single screen of user interface (ui) that appears in your app", CodersPocketDict.definition("activity")[1]);
        assertEquals( "conceptually integrated data collection that encapsulates state and behavior.", CodersPocketDict.definition("object")[1]);
    }
    @Test
    public void capFirstTest_01(){ // When taking input, the input is changed to lowercase
        assertEquals("Egg", CodersPocketDict.capFirst("egg"));
        assertEquals("Awesome", CodersPocketDict.capFirst("awesome"));
        assertEquals( "Computer", CodersPocketDict.capFirst("computer"));
    }
    @Test
    public void fillTest(){
        CodersPocketDict.fill();
        assertEquals(true, CodersPocketDict.dict.containsKey("activity"));
        assertEquals(true, CodersPocketDict.dict.containsValue("a single screen of user interface (ui) that appears in your app"));
        assertEquals(false, CodersPocketDict.dict.containsKey("water bottle"));
    }

}
